# cursor-build-animation

Skill para Claude que convierte un dashboard o pantalla HTML en una **animación de cursores colaborativos** (estilo Figma): 4, 8 o 12 cursores con nombre arman la interfaz pieza por pieza, con selecciones "Frame 593 × 283", manijas y guías de alineación, correcciones de posición, gráficos que se dibujan, contadores y una cámara que se aleja al final.

> English: a Claude skill that turns any HTML dashboard into a multi-cursor "team builds the UI live" animation. Zero dependencies, single-file output, MP4 export via Playwright + ffmpeg.

## Instalación

**Claude Code / Cowork:** copia esta carpeta como `~/.claude/skills/cursor-build-animation/`.

**Claude (web/escritorio):** comprime la carpeta `cursor-build-animation/` completa en un `.zip` (con `SKILL.md` dentro de ella) y súbelo en *Configuración → Capacidades → Skills*.

## Uso rápido

```bash
# Demo incluida: abre examples/dashboard-animation.html en el navegador

# Con tu propia UI ya anotada con data-b
python3 scripts/build.py --ui mi_ui.html --out animacion.html

# Con cualquier HTML sin anotar (anotación automática, 12 cursores, en inglés)
python3 scripts/build.py --ui pagina.html --auto --count 12 --lang en --out animacion.html

# Fotogramas de control y video (requiere: npm i playwright · ffmpeg)
node scripts/render.js animacion.html --out frames --stills 1,3,5,7,9,11,13
node scripts/render.js animacion.html --fps 30 --mp4 animacion.mp4
```

Con el skill instalado basta pedirle a Claude, por ejemplo: *"Haz una animación de cursores armando este dashboard"* y adjuntar el HTML.

## Controles de la animación

Espacio (pausa) · `R` (reiniciar) · ←/→ (±1 s) · barra de progreso clicable · velocidad 0.5×/1×/2× · 4/8/12 cursores · Bucle · Trayectorias.
Parámetros de URL: `?hud=0 · ?count=12 · ?speed=2 · ?loop=0 · ?paths=1 · ?labels=0 · ?lang=en · ?t=7`.

## Estructura

```
SKILL.md                 instrucciones para Claude (flujo, atributos, guion de tiempos, verificación)
runtime/cursor-build.js  motor sin dependencias
scripts/build.py         UI + runtime → HTML autónomo
scripts/render.js        fotogramas PNG / MP4 con Playwright
templates/ui-skeleton.html
examples/                dashboard de ejemplo (anotado y construido)
```

## Licencia

MIT — ver [LICENSE](LICENSE).
